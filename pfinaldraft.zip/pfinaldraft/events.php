<?php include("includes/header.php"); ?>
<body>

  <div id="fb-root"></div>
  <script>(function(d, s, id) {
    var js, fjs = d.getElementsByTagName(s)[0];
    if (d.getElementById(id)) return;
    js = d.createElement(s); js.id = id;
    js.src = 'https://connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.11';
    fjs.parentNode.insertBefore(js, fjs);
  }(document, 'script', 'facebook-jssdk'));</script>




<img id = "event" src = "images/event.jpg" alt = "Event1">

<div class="fb-page" data-href="https://www.facebook.com/cornellpokerclub/" data-tabs="event" data-width="800px" data-height="400px" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="false"><blockquote cite="https://www.facebook.com/cornellpokerclub/" class="fb-xfbml-parse-ignore"><a href="https://www.facebook.com/cornellpokerclub/">Cornell Poker Club</a></blockquote></div>
<p id = "eventinfo"> For more information on future events, please fill out the Forms link or email Jonathan Ho at jh964@cornell.edu and like the Facebook page. </p>


</body>

</html>

<!-- Poker Photo Background Image: https://www.peppermillreno.com//library/images/backgrounds/gaming_poker_cards.jpg
-->
