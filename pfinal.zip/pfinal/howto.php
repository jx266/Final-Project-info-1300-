<?php include("includes/header.php"); ?>

<body>
  <img id = "home" src = "images/home.jpg" alt = "Home">

<iframe id = "howto" width="1120" height="630" src="https://www.youtube.com/embed/b9HYxquQt-M" frameborder="0" allowfullscreen></iframe>
<p id = "howtotext"> Link: https://www.youtube.com/watch?v=b9HYxquQt-M&feature=youtu.be <p>
</body>

</html>


<!-- Poker Photo Background Image: https://www.peppermillreno.com//library/images/backgrounds/gaming_poker_cards.jpg
-->
