<?php include("includes/header.php"); ?>
<body>
  <img id = "home" src = "images/home.jpg" alt = "Home">



<img id = "event" src = "images/event.jpg" alt = "Event1">
<p id = "eventinfo"> For more information on future events, please fill out the Forms link or email Jonathan Ho at jh964@cornell.edu. </p>
</body>

</html>

<!-- Poker Photo Background Image: https://www.peppermillreno.com//library/images/backgrounds/gaming_poker_cards.jpg
-->
