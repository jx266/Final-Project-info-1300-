<?php include("includes/header.php"); ?>
<body>
  <img id = "home" src = "images/home.jpg" alt = "Home">

<p></p>
</body>

<div class="photos1">
  <img id="picture" src="images/001.jpg" alt="1">
</div>
<div class="photos1">
  <img id="picture" src="images/002.jpg" alt="2">
</div>
<div class="photos1">
  <img id="picture" src="images/003.png" alt="3">
</div>
<div class="photos1">
  <img id="picture" src="images/004.jpg" alt="4">
</div>
<div class="photos1">
  <img id="picture" src="images/007.jpg" alt="5">
</div>
<div class="photos1">
  <img id="picture" src="images/006.jpg" alt="6">
</div>

</html>

<!-- Poker Photo Background Image: https://www.peppermillreno.com//library/images/backgrounds/gaming_poker_cards.jpg
-->
