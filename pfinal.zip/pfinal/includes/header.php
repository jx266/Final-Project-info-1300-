<!DOCTYPE html>
<head>
<meta charset="UTF-8">
<title>Home</title>
<link rel="stylesheet" type="text/css" href="styles/all.css" media="all"/>
<link rel="stylesheet" href="styles/style.css">
</head>


<nav> <ul>
  <li><a href="index.php">Home</a></li>
  <li><a href="members.php">Members</a></li>
  <li><a href="pictures.php">Pictures</a></li>
  <li><a href="howto.php">How to Play</a></li>
  <li><a href="events.php">Previous Events</a></li>
  <li><a href="forms.php">Forms</a></li>




  </ul>
</nav>
