<?php include("includes/header.php"); ?>

<body>

<iframe id = "howto" width="747" height="420" src="https://www.youtube.com/embed/b9HYxquQt-M" frameborder="0" allowfullscreen></iframe>
<p id = "howtotext"> Link: https://www.youtube.com/watch?v=b9HYxquQt-M&feature=youtu.be <p>
</body>

</html>


<!-- Poker Photo Background Image: https://www.peppermillreno.com//library/images/backgrounds/gaming_poker_cards.jpg
-->
