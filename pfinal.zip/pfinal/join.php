<?php include("includes/header.php"); ?>
<body>
  <img id = "home" src = "images/home.jpg" alt = "Home">

<p> hi </p>
<input type="text" name="asda" value="">
</body>

</html>

<!-- Poker Photo Background Image: https://www.peppermillreno.com//library/images/backgrounds/gaming_poker_cards.jpg
-->
